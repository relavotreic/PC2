import numpy as np
from ejer2 import crea_arreglo as ca
from ejer3 import mueve_col 
x=int(input("filas="))
y=int(input("columnas= ")) 

print(np.array(ca(x,y)))
print(mueve_col)